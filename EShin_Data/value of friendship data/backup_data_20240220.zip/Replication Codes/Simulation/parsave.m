function parsave(fname, x)
  save(fname, 'x')
end