rm(list = ls())

library(dplyr)
library(haven)

load("C:/Users/hahn0/Desktop/RP_finalized_0904/data/finalized_panel_final.RData")
load("C:/Users/hahn0/Desktop/RP_finalized_0904/data/finalized_panel_individual.RData")

baseline_raw <- read_dta("C:/Users/hahn0/Desktop/RP_finalized_0904/data/for_graphs_baseline_raw.dta")

names(panel_individual)

# RA merge (time == 0 기준, id로)
RA_baseline <- panel_individual %>%
  filter(time == 0) %>%
  select(id, RA_i)

baseline_raw <- baseline_raw %>%
  left_join(RA_baseline, by = "id")

write_dta(baseline_raw, "data/for_graphs_baseline_raw.dta")


############################################################################

rm(list = ls())

library(dplyr)
library(haven)

load("C:/Users/hahn0/Desktop/RP_finalized_0904/data/finalized_panel_final.RData")
load("C:/Users/hahn0/Desktop/RP_finalized_0904/data/finalized_panel_individual.RData")

endline_raw <- read_dta("C:/Users/hahn0/Desktop/RP_finalized_0904/data/for_graphs_endline_raw.dta")

names(panel_individual)

# RA merge (time == 1 기준, id로)
RA_endline <- panel_individual %>%
  filter(time == 1) %>%
  select(id, RA_i)

endline_raw <- endline_raw %>%
  left_join(RA_endline, by = "id")

write_dta(endline_raw, "data/for_graphs_endline_raw.dta")

############################################################################

rm(list = ls())

library(dplyr)
library(haven)

load("C:/Users/hahn0/Desktop/RP_finalized_0904/data/finalized_panel_final.RData")
load("C:/Users/hahn0/Desktop/RP_finalized_0904/data/finalized_panel_individual.RData")

baseline_raw <- read_dta("C:/Users/hahn0/Desktop/RP_finalized_0904/data/for_graphs_baseline_raw.dta")

names(panel_individual)

# RA merge (time == 0 기준, id로)
RA_baseline <- panel_individual %>%
  filter(time == 0) %>%
  select(id, RA_g)

baseline_raw <- baseline_raw %>%
  left_join(RA_baseline, by = "id")

write_dta(baseline_raw, "data/for_graphs_baseline_raw.dta")


############################################################################

rm(list = ls())

library(dplyr)
library(haven)

load("C:/Users/hahn0/Desktop/RP_finalized_0904/data/finalized_panel_final.RData")
load("C:/Users/hahn0/Desktop/RP_finalized_0904/data/finalized_panel_individual.RData")

endline_raw <- read_dta("C:/Users/hahn0/Desktop/RP_finalized_0904/data/for_graphs_endline_raw.dta")

names(panel_individual)

# RA merge (time == 1 기준, id로)
RA_endline <- panel_individual %>%
  filter(time == 1) %>%
  select(id, RA_g)

endline_raw <- endline_raw %>%
  left_join(RA_endline, by = "id")

write_dta(endline_raw, "data/for_graphs_endline_raw.dta")
